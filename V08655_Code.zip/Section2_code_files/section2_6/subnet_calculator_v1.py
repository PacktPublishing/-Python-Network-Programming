#!/usr/bin/env python3

class subnet_calculator:
    def __init__(self, network):
        self.network = network


if __name__ == "__main__":
    print("Hello World")

