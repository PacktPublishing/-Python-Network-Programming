#!/usr/bin/env python3

def hello(word):
    print("Hello " + word)

if __name__ == "__main__":
    hello("network world")

